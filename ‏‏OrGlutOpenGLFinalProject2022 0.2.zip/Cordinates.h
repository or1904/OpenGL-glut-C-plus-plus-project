#pragma once

#ifndef CORDINATES
#define CORDINATES

#include <math.h>

struct Cordinates
{
	float x, y, z;

	Cordinates sum(Cordinates another)
	{
		return Cordinates{ this->x + another.x, this->y + another.y, this->z + another.z};
	}

	Cordinates sub_for_vector_with(Cordinates another)
	{
		return Cordinates{ this->x - another.x, this->y - another.y, this->z - another.z };
	}

	float len()
	{
		return sqrt(this->x * this->x + this->y * this->y + this->z * this->z);
	}

	Cordinates scalar_product(float t)
	{
		return Cordinates{t * this->x, t * this->y, t * this->z};
	}

	float scalar_product_vector(Cordinates another)
	{
		return this->x * another.x + this->y * another.y + this->z * another.z;
	}

	double getDistanceWith(Cordinates cords)
	{
		double distance = sqrtf(powf((double)cords.x - (double)this->x, 2) +
			pow((double)cords.y - (double)this->y, 2) +
			pow((double)cords.z - (double)this->z, 2));

		return distance;
	}
};

#endif