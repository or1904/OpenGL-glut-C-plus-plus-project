#include "Ball.h"

Ball::Ball() : id_num(), r(), m(), nobs_to_summon(), color(), start_cordinator_position(), cordinator_position(), alpha_movement(), new_alpha_movement(), beta_movement(), new_beta_movement(), t(), new_t(), is_exploding() {}

Ball::Ball(int id_num, float r, float start_cordinator_position[3], float cordinator_position[3], float m, float alpha, float beta, float num_of_balls_to_summon, float color[3], bool is_drawn) :
	id_num(id_num),
	r(r),
	m(m),
	nobs_to_summon(num_of_balls_to_summon),
	color{ color[0], color[1], color[2] },
	start_cordinator_position{ start_cordinator_position[0], start_cordinator_position[1], start_cordinator_position[2] },
	cordinator_position{ cordinator_position[0], cordinator_position[1], cordinator_position[2] },
	alpha_movement(alpha),
	beta_movement(beta),
	new_alpha_movement(alpha),
	new_beta_movement(beta),
	t(0),
	new_t(0),
	is_exploding(false)
{}

int Ball::getIdNum()
{
	return id_num;
}

float Ball::getM()
{
	return m;
}

float Ball::getColor(int i)
{
	return color[i];
}

void Ball::reset_start_pos_of_ball()
{	
	for (int i = 0; i < 3; i++)
		this->start_cordinator_position[i] = this->cordinator_position[i];
	this->t = 0;
}

void Ball::refresh_t()
{
	this->t = this->new_t;
	alpha_movement = this->new_alpha_movement;
	beta_movement = this->new_beta_movement;

	this->new_t = 0;
}

void Ball::secure_angles()
{
	alpha_movement = this->new_alpha_movement;
	beta_movement = this->new_beta_movement;
}

