﻿//#include <iostream>
#include <stdlib.h>
#include <glut.h>
#include <math.h>
#include <time.h>
#include <cctype> //to inverse upper keys to lower

#include "Main.h"

extern const double PI = 3.1415926535897932384626433832795;
const float XWINSIZE = 1000;
const float YWINSIZE = 1000;

//settings variables:
float XLeft = -1000, XRight = 1000, YDown = -1000, YUp = 1000, ZNear = -1000, ZFar = 1000;
float curr_left = XLeft, curr_right = XRight, curr_down = YDown, curr_up = YUp, curr_near = ZNear, curr_far = ZFar;
float curr_XWinSize = XWINSIZE, curr_YWinSize = YWINSIZE;
float cam_angle_view = 60, cam_propotion = 1;
float cam_min_d = 0.01, cam_max_d = 200; // cam_max_d > cam_min_d > 0
float angle_distortion = 0.9, cam_max_rotate_speed = 40, player_turn_speed = 4;
float start_cx = 0, start_cy = 0, start_cz = 0;
float cam_x = start_cx, cam_y = start_cy, cam_z = start_cz;
double cam_alpha = 0, cam_beta = 0, start_cam_alpha = cam_alpha, start_cam_beta = cam_beta;
Cordinates cam_cords;
float character_speed = 0.3;
bool on_fullscreen = false;
bool is_window_focused = true;
bool is_contiue_playing = true;
bool is_list_not_running = true;
bool is_player_win = false;

bool show_home_screen = true;
bool is_game_start = false;
bool show_results_screen = false;
bool show_guide_screen = false;
bool show_credits_screen = false;
bool show_pause_screen = false;

GLuint index[7]; //for using GL_LISTS 

//mouse mark
float mouse_mark_cr = 0.001, mouse_mark_cd = cam_min_d + 0.1;

// player + player's gravity settings:
float g = -10; // in m/s^2
float player_jump_distance = 5; //im meters
float start_jump_speed;
float current_jump_distance = 0;
float next_current_jump_distance = 0;
float player_height_above_0 = 5; //in meters
bool is_jump = false;
float player_color[4] = { 0.6, 0.8, 1, 0.8};
float player_tops_r = 1;
Cordinates loosing_cam_cords;

//room variables:
float room_length = 100; // length of walls
float room_height = 50;
float wires_width = 0.25;
float custom_wall_length = 2, custom_floor_length = 2; //per 1 "block"
float custom_wall_height = 2.2, custom_floor_height = 2; //per 1 "block"
float wires_bulge_z = 0.1;
float wall_color[] = { 0, 0, 0 };
float wires_color[] = { 0.2, 0.2, 0.6 };

//input variables:
bool keypressed[256]; // array that saves if a key is pressed or not;
bool mouse[3]; // array that saves if a button is pressed or not: 0 - left button, 1 - while button, 2 - right button;
float dx, dy;

//time variables:
time_t t;
float i = 0; //in seconds (1000 mili-sec = 1 sec)
float delay_ball_summon = 1000; // each ball, in mili-seconds (1000 = 1sec)
int d1 = 0, d2 = 1, d3 = 2;
double time_scale = 0.02;
float delay_play_time = 1000; //in mili-seconds (1000 = 1sec)
bool can_start_move = false; //bound to timer 1
int bs_counter = 0; //bs - ball_summon, bound to timer 2
bool is_deley_d2_called = false;
float delay_game_over_time = 8000;
bool is_game_end = false;

//balls management variables:
int ball_start_id_num = -1; //oficial
int num_of_balls = 15;
float balls_start_m = 1; //in kg
float max_radius = 5;
float balls_start_position[3] = { 0, 25, -25 }; //common to all
float balls_r = max_radius;
float balls_start_speed = 16;
float error_color[] = { 1, 1, 1 };
Node<Ball>* ball_list = new Node<Ball>{ Ball(-1, 1, balls_start_position, balls_start_position, -1, -1, -1, -1,
		error_color, false), nullptr }; //השמת ערכים לטיפוס נתונים של ball

//explosion
float explosions_color[3] = { 0, 1, 0 };
float explosions_min_r = 3; 
float explosions_max_r = 20;
float explosions_total_time = 0.8; //in seconds


//gun management variables:
double gun_position_x_pro_to_player = 0.4; //positive to right, negative to left
double gun_position_y_pro_to_player = -0.3; //positive to up, negative to down
double gun_position_z_pro_to_player = 0; //positive to forward, negaive to backward, according to (any) camera view.
float gun_angle_x = 8; //direction against the clock

float gun_body_width = 0.05;
float gun_body_length = 0.7;
float gun_body_color[3] = {0.8, 0, 0.2};

float gun_spring_width = 0.04;
float gun_spring_layer = -1; // needs to be < 0
float gun_spring_circles_len = 0.01; // len when is on loose
int gs_circles_num = 45;
float gun_spring_color[3] = {0.82, 0.82, 0.88};
float gs_total_start_len = 0.1;
float max_glove_length = 50;

float glove_r = 0.15;
float glove_color[3] = { 0, 0.4, 1 };
bool is_gun_shooting = false;
bool is_max_extention_reached = false;
float spring_extention = 0;
float shooting_speed = 5;
double shooting_cam_alpha, shooting_cam_beta;
double shoot_angle_alpha = shooting_cam_alpha, shoot_angle_beta = shooting_cam_beta;
Cordinates shooting_cam_cords;
Cordinates glove_cords;

Cordinates player_top_cords;
Cordinates player_middle_cords;
Cordinates player_bottom_cords;

//texts: fonts
void* font = GLUT_STROKE_ROMAN;
void* font2 = GLUT_STROKE_MONO_ROMAN;

//background colors:
float b_home_color[3] = { 0.2, 0.4, 1};
float b_loose_color[3] = { 1, 0.6, 0.6 };
float b_guide_color[3] = { 0, 0, 0 };
float b_credits_color[3] = { 0.1, 0, 0.1 };
float b_pause_color[3] = {0.8, 1, 1};

//texts:
float tr_title_color[3] = { 1, 1, 0.2 }; //tr - testroom
float ws_color[3] = {0.4, 1, 0.6}; // ws - win sign
float ls_color[3] = { 1, 0.4, 0.6 }; // ls - loose sign
float rules_color[3] = {1, 1, 1};
float credits_color[3] = { 1, 1, 0.6 };
float pause_color[3] = { 0.8, 0.8, 0.8 };

Text title = { (const unsigned char*)"TESTROOM-AGILITY", 
font, Cordinates{0, 550, 0}, tr_title_color, 7, 1, true, true };
Text sub_title = { (const unsigned char*)"a game project made by Or Benyaminovich",
font, Cordinates{0, 250, 0}, tr_title_color, 2, 0.5, true, false };

Text pause_txt = { (const unsigned char*)"PAUSE SCREEN",
font, Cordinates{0, 550, 0}, pause_color, 7, 1, true, true };
Text sub_pause_txt = { (const unsigned char*)"click left click anywhere on the game screen to contiue",
font, Cordinates{0, 250, 0}, pause_color, 3, 0.5, true, false };

Text gh_title_txt = { (const unsigned char*)"how to play?",
font, Cordinates{0, 750, 0}, rules_color, 7, 1, true, true };
Text gh_txt_b1 = { (const unsigned char*)"(most buttons/keybaords can be hold/pressed at the same time)",
font2, Cordinates{0, 670, 0}, rules_color, 2, 0.3, true, false };
Text gh_txt = { (const unsigned char*)"Player Movement: A W D S keys.",
font2, Cordinates{-1000, 600, 0}, rules_color, 3, 0.4, false, false };
Text gh_txt2 = { (const unsigned char*)"Change point of view: with the mouse",
font2, Cordinates{-1000, 510, 0}, rules_color, 3, 0.4, false, false };
Text gh_txt3 = { (const unsigned char*)"Shoot: mouse left click",
font2, Cordinates{-1000, 420, 0}, rules_color, 3, 0.4, false, false };
Text gh_txt4 = { (const unsigned char*)"Jump: space key",
font2, Cordinates{-1000, 330, 0}, rules_color, 3, 0.4, false, false };
Text gh_txt5 = { (const unsigned char*)"FullScreen/defiend screen size: f11 key",
font2, Cordinates{-1000, 240, 0}, rules_color, 3, 0.4, false, false };
Text gh_txt_b6 = { (const unsigned char*)"(f11 key cant be hold)",
font2, Cordinates{0, 190, 0}, rules_color, 2, 0.3, true, false };
Text gh_txt6 = { (const unsigned char*)"Quit: q key",
font2, Cordinates{-1000, 150, 0}, rules_color, 3, 0.4, false, false };
Text gh_txt7 = { (const unsigned char*)"Your goal is to shoot all the balls.",
font2, Cordinates{-1000, 60, 0}, rules_color, 3, 0.4, false, false };
Text gh_txt8 = { (const unsigned char*)"You loose if you hit by any ball.",
font2, Cordinates{-1000, -30, 0}, rules_color, 3, 0.4, false, false };

Text credits_title_txt = { (const unsigned char*)"Credits:",
font2, Cordinates{0, 750, 0}, credits_color, 7, 1, true, true };
Text c_txt_b1 = { (const unsigned char*)"(names not written due to respect for their anonymity)",
font2, Cordinates{0, 670, 0}, rules_color, 2, 0.3, true, false };
Text c_txt = { (const unsigned char*)"Special thanks to:",
font2, Cordinates{-1000, 600, 0}, rules_color, 3, 0.4, false, false };
Text c_txt2 = { (const unsigned char*)"My friends",
font2, Cordinates{0, 510, 0}, credits_color, 3, 0.6, true, false };
Text c_txt3 = { (const unsigned char*)"My Teachers",
font2, Cordinates{0, 420, 0}, credits_color, 3, 0.6, true, false };
Text c_txt4 = { (const unsigned char*)"My family",
font2, Cordinates{0, 330, 0}, credits_color, 3, 0.6, true, false };
Text c_txt_last = { (const unsigned char*)"Game made by:",
font2, Cordinates{-1000, -30, 0}, rules_color, 3, 0.4, false, false };
Text c_txt_last2 = { (const unsigned char*)"Or Benyaminovitch",
font2, Cordinates{-425, -30, 0}, credits_color, 3, 0.4, false, false };


Text win_sign = { (const unsigned char*)"YOU WIN!",
font2, Cordinates{0, 550, 0}, ws_color, 7, 1, true, true };
Text sub_win_sign = { (const unsigned char*)"Thanks for playing!",
font2, Cordinates{0, 250, 0}, ws_color, 2, 0.5, true, false };

Text loose_sign = { (const unsigned char*)"GAME OVER",
font, Cordinates{0, 550, 0}, ls_color, 7, 1, true, true };
Text sub_win_loose = { (const unsigned char*)"''Science without religion is lame,",
font2, Cordinates{0, 300, 0}, ls_color, 3, 0.4, true, true };
Text sub_win_loose2 = { (const unsigned char*)"religion without science is blind.''",
font2, Cordinates{0, 240, 0}, ls_color, 3, 0.4, true, true };
Text sub_win_loose3 = { (const unsigned char*)"- Albert Einstein",
font2, Cordinates{0, 170, 0}, ls_color, 3, 0.4, true, false };


//buttons:
float pb_color[3] = { 0.6, 1, 0.8 }; //pb - play button
float pbf_color[3] = { 1, 0.8, 1 }; //pbf - play button field
float gt_color[3] = { 0.8, 1, 0.6 }; //gtf - guild title
float gtf_color[3] = { 0, 0, 0.4 }; //gtf - guild title field

float cf_color[3] = { 0.6, 0.8, 1 }; //cf - credits field


Text guide_title_txt = { (const unsigned char*)"how to play?",
font, Cordinates{400, -100, 0}, gt_color, 2, 0.5, true, false };
Text back_title_txt = { (const unsigned char*)"back",
font, Cordinates{400, -100, 0}, pb_color, 2, 0.5, true, false };
Text back_title_txt2 = { (const unsigned char*)"back",
font, Cordinates{0, -500, 0}, pb_color, 2, 0.5, true, false };
Text play_button_txt = { (const unsigned char*)"start",
font, Cordinates{0, -400, 0}, pb_color, 2, 0.5, true, false };
Text play_again_txt = { (const unsigned char*)"play_again",
font2, Cordinates{-400, -100, 0}, pb_color, 2, 0.5, true, false };
Text try_again_txt = { (const unsigned char*)"try_again!",
font2, Cordinates{-400, -100, 0}, pb_color, 2, 0.5, true, false };
Text credits_txt = { (const unsigned char*)"Credits",
font, Cordinates{-400, -100, 0}, credits_color, 2, 0.5, true, false };

Button play_button = {play_button_txt, 200, 180, pbf_color};
Button play_again_button = { play_again_txt, 600, 300, pbf_color };
Button try_again_button = { try_again_txt, 600, 300, pbf_color };
Button guide_title_button = { guide_title_txt, 600, 300, gtf_color };
Button back_title_button = { back_title_txt, 600, 300, pbf_color };
Button back_title_button2 = { back_title_txt2, 600, 300, pbf_color };
Button credit_button = { credits_txt, 600, 300, cf_color };


void display2D(void)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	if (show_home_screen)
	{
		glClearColor(b_home_color[0], b_home_color[1], b_home_color[2], 1);
		glPushMatrix();
		draw_text(title);
		draw_text(sub_title);
		draw_button(play_button);
		draw_button(guide_title_button);
		draw_button(credit_button);
		glPopMatrix();
	}
	else if (show_results_screen)
	{
		glClearColor(b_home_color[0], b_home_color[1], b_home_color[2], 1);

		if (is_player_win)
		{
			draw_text(win_sign);
			draw_text(sub_win_sign);
			draw_button(play_again_button);
			draw_button(back_title_button);
		}
		else
		{
			glClearColor(b_loose_color[0], b_loose_color[1], b_loose_color[2], 1);
			draw_text(loose_sign);
			draw_text(sub_win_loose);
			draw_text(sub_win_loose2);
			draw_text(sub_win_loose3);
			draw_button(try_again_button);
			draw_button(guide_title_button);
			draw_button(back_title_button2);
		}
	}
	else if (show_guide_screen)
	{
		glClearColor(b_guide_color[0], b_guide_color[1], b_guide_color[2], 1);
		draw_text(gh_title_txt);
		draw_text(gh_txt_b1);
		draw_text(gh_txt);
		draw_text(gh_txt2);
		draw_text(gh_txt3);
		draw_text(gh_txt4);
		draw_text(gh_txt5);
		draw_text(gh_txt_b6);
		draw_text(gh_txt6);
		draw_text(gh_txt7);
		draw_text(gh_txt8);
		draw_button(back_title_button2);
	}
	else if (show_credits_screen)
	{
		glClearColor(b_credits_color[0], b_credits_color[1], b_credits_color[2], 1);
		draw_text(credits_title_txt);
		draw_text(c_txt_b1);
		draw_text(c_txt);
		draw_text(c_txt2);
		draw_text(c_txt3);
		draw_text(c_txt4);
		draw_text(c_txt_last);
		draw_text(c_txt_last2);
		draw_button(back_title_button2);
	}
	else if (show_pause_screen)
	{
		glClearColor(b_pause_color[0], b_pause_color[1], b_pause_color[2], 1);

		draw_text(pause_txt);
		draw_text(sub_pause_txt);
	}

	glutSwapBuffers();
	glFlush();
}

void display(void) {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	//gun:
	if (!is_game_end)
	{
		glPushMatrix();

		//gun-body
		glPushMatrix();
		glTranslatef(gun_position_x_pro_to_player, gun_position_y_pro_to_player, -gun_position_z_pro_to_player);
		glRotatef(180 + gun_angle_x, 0, 1, 0); // considering z axe is opssite to persective axe
		glCallList(index[1]); //draw_gun_body(...);
		glPopMatrix();

		//gun-spring

		if (!is_gun_shooting)
		{
			glPushMatrix();
			glTranslatef(gun_position_x_pro_to_player - gun_body_length * sin(gun_angle_x * PI / 180),
				gun_position_y_pro_to_player, -(gun_position_z_pro_to_player + gun_body_length * cos(gun_angle_x * PI / 180)));
			glRotatef(180 + gun_angle_x, 0, 1, 0);
			glCallList(index[2]); //draw_gun_spring(...);
			glPopMatrix();

			//glove (its a ball)
			glPushMatrix();
			glTranslatef(gun_position_x_pro_to_player - (gun_body_length + gs_total_start_len + glove_r)
				* sin(gun_angle_x * PI / 180), gun_position_y_pro_to_player,
				-(gun_position_z_pro_to_player + (gun_body_length + gs_total_start_len + glove_r) * cos(gun_angle_x * PI / 180)));
			glCallList(index[3]); //draw_glove(...);
			glPopMatrix();
		}
		glPopMatrix();

		//mouse mark
		glPushMatrix();
		glCallList(index[6]);//mouse_mark();
		glPopMatrix();
	}

	//cam
	cam_cords = { cam_x, cam_y + player_height_above_0 + current_jump_distance, cam_z };

	gluLookAt(cam_cords.x, cam_cords.y, cam_cords.z,
		cam_x - player_turn_speed * sin(cam_alpha * PI / 180) * cos(cam_beta * PI / 180),
		cam_y + player_height_above_0 + current_jump_distance + player_turn_speed * sin(cam_beta * PI / 180),
		cam_z + player_turn_speed * cos(cam_alpha * PI / 180) * cos(cam_beta * PI / 180),
		0, 1, 0);

	//gun_spring + glove (in shooting). including also body:
	if (is_gun_shooting || is_game_end)
	{
		glPushMatrix();

		//gun-body	
		if (is_game_end)
		{
			glPushMatrix();

			Cordinates body_gun_cords =
				get_position_prob_to_player(gun_position_x_pro_to_player, gun_position_y_pro_to_player, 
					gun_position_z_pro_to_player, shooting_cam_alpha, shooting_cam_beta, loosing_cam_cords);
			glTranslatef(body_gun_cords.x, body_gun_cords.y, body_gun_cords.z);
			glRotatef(-shooting_cam_beta, cos(shooting_cam_alpha * PI / 180), 0, sin(shooting_cam_alpha * PI / 180));
			//based on:
			//	1) glRotatef(-cam_beta * cos(cam_alpha * PI / 180), 1, 0, 0);
			//	2) glRotatef(-cam_beta * sin(cam_alpha * PI / 180), 0, 0, 1);

			//	becasue the (1) rotate is affected by (2) rotate, the based code is not working.
			//	Therefore, i needed to do it by a single roatete, so the chosen axes are chosen "partially",
			//	depended on the camera angles,
			//
			glRotatef(gun_angle_x - shooting_cam_alpha, 0, 1, 0);
			draw_gun_body(gun_body_width, gun_body_length, gun_body_color);
			glPopMatrix();
		}

		//gun-spring
		glPushMatrix();
		Cordinates spring_gun_cords;
		if (!is_game_end)
			spring_gun_cords = get_position_prob_to_player(gun_position_x_pro_to_player - gun_body_length * sin(gun_angle_x * PI / 180),
				gun_position_y_pro_to_player,
				gun_position_z_pro_to_player + gun_body_length * cos(gun_angle_x * PI / 180));
		else
			spring_gun_cords = get_position_prob_to_player(gun_position_x_pro_to_player - gun_body_length * sin(gun_angle_x * PI / 180),
				gun_position_y_pro_to_player,
				gun_position_z_pro_to_player + gun_body_length * cos(gun_angle_x * PI / 180), shooting_cam_alpha, shooting_cam_beta, loosing_cam_cords);
		glTranslatef(spring_gun_cords.x, spring_gun_cords.y, spring_gun_cords.z);

		float spring_angle_beta = -(shoot_angle_beta + shooting_cam_beta);
		float spring_angle_alpha = shoot_angle_alpha - shooting_cam_alpha;

		if (gun_position_x_pro_to_player - gun_body_length * sin(gun_angle_x * PI / 180) < 0)
			spring_angle_alpha -= 180;

		glRotatef(spring_angle_beta, cos(shooting_cam_alpha * PI / 180), 0, sin(shooting_cam_alpha * PI / 180));
		/*based on:
			1) glRotatef(-cam_beta * cos(cam_alpha * PI / 180), 1, 0, 0);
			2) glRotatef(-cam_beta * sin(cam_alpha * PI / 180), 0, 0, 1);

			becasue the (1) rotate is affected by (2) rotate, the based code is not working.
			Therefore, i needed to do it by a single roatete, so the chosen axes are chosen "partially",
			depended on the camera angles.
		*/
		glRotatef(spring_angle_alpha, 0, 1, 0);
		glScalef(1, 1, 1 + spring_extention);
		glCallList(index[2]); //draw_gun_spring(...);
		glPopMatrix();

		//glove
		glPushMatrix();

		Cordinates hit_point;
		if (!is_game_end)
		{
			glove_cords = get_position_prob_to_player(
				gun_position_x_pro_to_player - (gun_body_length + gs_total_start_len + glove_r) * sin(gun_angle_x * PI / 180),
				gun_position_y_pro_to_player,
				gun_position_z_pro_to_player + (gun_body_length + gs_total_start_len + glove_r) * cos(gun_angle_x * PI / 180),
				shooting_cam_alpha, shooting_cam_beta);

			hit_point = get_position_prob_to_player(0, 0, gun_position_z_pro_to_player + gun_body_length * cos(gun_angle_x) + max_glove_length + glove_r, shooting_cam_alpha, shooting_cam_beta);
		}
		else
		{
			glove_cords = get_position_prob_to_player(
				gun_position_x_pro_to_player - (gun_body_length + gs_total_start_len + glove_r) * sin(gun_angle_x * PI / 180),
				gun_position_y_pro_to_player,
				gun_position_z_pro_to_player + (gun_body_length + gs_total_start_len + glove_r) * cos(gun_angle_x * PI / 180),
				shooting_cam_alpha, shooting_cam_beta, loosing_cam_cords);

			hit_point = get_position_prob_to_player(0, 0, gun_position_z_pro_to_player + gun_body_length * cos(gun_angle_x) + max_glove_length + glove_r, shooting_cam_alpha, shooting_cam_beta, loosing_cam_cords);
		}

		Cordinates vector_r = hit_point.sub_for_vector_with(spring_gun_cords);

		glove_cords = glove_cords.sum(vector_r.scalar_product(1 / (max_glove_length / (spring_extention * gs_total_start_len))));

		glTranslatef(glove_cords.x, glove_cords.y, glove_cords.z);
		glCallList(index[3]); //draw_glove(...);
		glPopMatrix();

		glPopMatrix();
	}

	//room
	glPushMatrix();
	glCallList(index[0]); //create_custom_room();
	glPopMatrix();

	//balls
	glPushMatrix();
	draw_balls_and_explosions();
	glPopMatrix();


	//player
	if (is_game_end)
	{
		glPushMatrix();
		glTranslatef(loosing_cam_cords.x, loosing_cam_cords.y, loosing_cam_cords.z);
		glCallList(index[5]); //draw_player(player_tops_r, player_height_above_0, player_color);
		glPopMatrix();
	}

	//test player bean
	/*glPushMatrix();
	glColor3f(0.5, 0.6, 0.2);
	glTranslatef(player_top_cords.x, player_top_cords.y, player_top_cords.z + 5);
	glutSolidSphere(1, 100, 100);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.5, 0.6, 0.2);
	glTranslatef(player_middle_cords.x, player_middle_cords.y, player_middle_cords.z + 5);
	glutSolidSphere(1, 100, 100);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.5, 0.6, 0.2);
	glTranslatef(player_bottom_cords.x, player_bottom_cords.y , player_bottom_cords.z + 5);
	glutSolidSphere(1, 100, 100);
	glPopMatrix();*/

	glutSwapBuffers();
	glFlush();
}

void delay_func(int value)
{
	switch (value)
	{
	case 0:
		can_start_move = true;
		break;
	case 1:
		bs_counter++;
		is_deley_d2_called = false;
		break;
	case 2:
		close_game_and_show_results();
	default:
		break;
	}
}

Node<Ball>* create_a_ball()
{
	float ball_color[3], start_alpha, start_beta;
	for (int i2 = 0; i2 < 3; i2++)
	{
		ball_color[i2] = rand() % 257 / 256.0;
	}
	start_alpha = rand() % 360;
	start_beta = rand() % 360;

	ball_start_id_num++;
	return new Node<Ball>{ Ball(ball_start_id_num, balls_r, balls_start_position, balls_start_position, balls_start_m, 
		start_alpha, start_beta, 1, ball_color, false), nullptr}; //השמת ערכים לטיפוס נתונים של ball
}

void create_balls()
{
	float ball_color[3], start_alpha, start_beta;
	Ball* ball;
	Node<Ball>* p = new Node<Ball>;

	p = ball_list;
	for (int i = 0; i < num_of_balls; i++)
	{
		p->next = create_a_ball(); //p != nullptr
		p = p->next;
	}

	//test:
	/*int error = 1000;
	Node<Ball>* follower = ball_list;
	while (follower != nullptr)
	{
		printf("ball:%f\n\n", follower->value.alpha_movement);
		follower = follower->next;
		error--;
		if (error < 0)
		{
			printf("ERROR\n\n");
			exit(0);
		}
	}*/
}

void draw_balls_and_explosions()
{
	Node<Ball>* saver = ball_list->next;
	draw_a_ball_and_explosion(saver, 0, 0);
}

void set_next_ball_position(Node<Ball>* ball)
{

	double d_common = balls_start_speed * ball->value.t * time_scale; //without x0 (x = x0 + v0t + at^2/2)
	ball->value.cordinator_position[0] = ball->value.start_cordinator_position[0] + d_common * sin(ball->value.beta_movement * PI / 180) * sin(ball->value.alpha_movement * PI / 180);
	ball->value.cordinator_position[1] = ball->value.start_cordinator_position[1] + d_common * cos(ball->value.beta_movement * PI / 180);
	ball->value.cordinator_position[2] = ball->value.start_cordinator_position[2] + d_common * sin(ball->value.beta_movement * PI / 180) * cos(ball->value.alpha_movement * PI / 180);
}

void draw_a_ball_and_explosion(Node<Ball>* b, int counter, float d_common)
{
	if (b != nullptr)
	{
		if (counter >= bs_counter && !is_deley_d2_called)
		{
			is_deley_d2_called = true;
			glutTimerFunc(delay_ball_summon, delay_func, d2);
		}
		else if (counter < bs_counter)
		{
			glPushMatrix();
			if (b->value.is_exploding)
			{
				glTranslatef(b->value.cordinator_position[0], b->value.cordinator_position[1], b->value.cordinator_position[2]);
				glScalef(b->value.r, b->value.r, b->value.r);
				glCallList(index[4]); //custom3D_circle
			}
			else
			{
				set_next_ball_position(b);
				glTranslatef(b->value.cordinator_position[0], b->value.cordinator_position[1], b->value.cordinator_position[2]);
				glColor3f(b->value.getColor(0), b->value.getColor(1), b->value.getColor(2));
				glutSolidSphere(b->value.r, 100, 100);
			}
			glPopMatrix();

			draw_a_ball_and_explosion(b->next, counter + 1, d_common);
		}
	}
}

void set_new_ball_angle(Node<Ball>* ball, int wall)
{
	switch (wall)
	{
	case 1:
		if(sin(ball->value.beta_movement * PI / 180) * sin(ball->value.alpha_movement * PI / 180) > 0)
			ball->value.new_alpha_movement = -ball->value.alpha_movement;
		//else
		//	printf("\n=============================\nerror detected(%i)\n==============================\n\n", ball->value.getIdNum());
		break;
	case 2:
		if(sin(ball->value.beta_movement * PI / 180) * sin(ball->value.alpha_movement * PI / 180) < 0)
			ball->value.new_alpha_movement = -ball->value.alpha_movement;
		//else
		//	printf("\n=============================\nerror detected(%i)\n==============================\n\n", ball->value.getIdNum());
		break;
	case 3:
		if(cos(ball->value.beta_movement * PI / 180) > 0)
			ball->value.new_beta_movement = 180 - ball->value.beta_movement;
		//else
		//	printf("\n=============================\nerror detected(%i)\n==============================\n\n", ball->value.getIdNum());
		break;
	case 4:
		if(cos(ball->value.beta_movement * PI / 180) < 0)
			ball->value.new_beta_movement = 180 - ball->value.beta_movement;
		//else
		//	printf("\n=============================\nerror detected(%i)\n==============================\n\n", ball->value.getIdNum());
		break;
	case 5:
		if(sin(ball->value.beta_movement * PI / 180) * cos(ball->value.alpha_movement * PI / 180) > 0)
			ball->value.new_alpha_movement = 180 - ball->value.alpha_movement;
		//else
		//	printf("\n=============================\nerror detected(%i)\n==============================\n\n", ball->value.getIdNum());
		break;
	case 6:
		if(sin(ball->value.beta_movement * PI / 180) * cos(ball->value.alpha_movement * PI / 180) < 0)
			ball->value.new_alpha_movement = 180 - ball->value.alpha_movement;
		//else
		//	printf("\n=============================\nerror detected(%i)\n==============================\n\n", ball->value.getIdNum());
		break;
	case -1:
		ball->value.new_alpha_movement = rand() % 360;
		ball->value.new_beta_movement = rand() % 360;
		//ball->value.new_alpha_movement = 90;
		break;

	default:
		printf("\nERROR: At get_new_ball_angle()\n");
		break;
	}
}

double get_coll_t(Node<Ball>* ball, int wall)
{
	// base on: x = x0 + v0t + at^2/2 = > t * time_scale= (x-x0)/v
	double distance = 0, speed = 0;
	float t_saver = 0;

	switch (wall)
	{
	case 1: // alpha != 0 or 180  (right)
		distance = room_length / 2.0 - (double)(wires_bulge_z) - ((double)ball->value.start_cordinator_position[0] + (double)ball->value.r);
		speed = (double)(balls_start_speed * time_scale) * sin(ball->value.beta_movement * PI / 180) * sin((ball->value.alpha_movement) * PI / 180);
		break;
	case 2: // alpha != 0 or 180  (left)
		distance = (double)ball->value.start_cordinator_position[0] - (double)ball->value.r - (-room_length / 2.0 + (double)(wires_bulge_z));
		speed = (double)(balls_start_speed * time_scale) * sin(ball->value.beta_movement * PI / 180) * sin((double)(-ball->value.alpha_movement) * PI / 180);
		break;
	case 3: // beta != 90 or 270  (up)
		distance = ((double)room_height - (double)wires_bulge_z) - ((double)ball->value.start_cordinator_position[1] + (double)ball->value.r);
		speed = (double)(balls_start_speed * time_scale) * cos(ball->value.beta_movement * PI / 180);
		break;
	case 4:  // beta != 90 or 270  (down)
		distance = ((double)ball->value.start_cordinator_position[1] - (double)ball->value.r) - (0 + (double)wires_bulge_z);
		speed = (double)(balls_start_speed * time_scale) * cos((double)(180 - ball->value.beta_movement) * PI / 180); // floor is placed on plain 0
		break;
	case 5: // alpha != 90 or 270  (forward, from world's persective view)
		distance = room_length / 2.0 - (double)(wires_bulge_z)- ((double)ball->value.start_cordinator_position[2] + (double)ball->value.r);
		speed = (double)(balls_start_speed * time_scale) * sin(ball->value.beta_movement * PI / 180) * cos(ball->value.alpha_movement * PI / 180);
		break;
	case 6: // alpha != 90 or 270 (backward, from world's persective view)
		distance = (double)ball->value.start_cordinator_position[2] - (double)ball->value.r - (-room_length / 2.0 + (double)(wires_bulge_z));
		speed = (double)(balls_start_speed * time_scale) * sin(ball->value.beta_movement * PI / 180) * cos((double)(180 - ball->value.alpha_movement) * PI / 180);
		break;
	}
	if ((float)speed != 0)
	{
		t_saver = (float)(distance / speed);
	}
	else //error test
	{
		printf("\nERROR: At get_coll_t()\n");
		exit(1);
	}

	return t_saver;
}

void get_discriminanta_b_a_solution(Ball tested_ball, Ball ball2, double *dba)
{
	double xa = (double)tested_ball.start_cordinator_position[0];
	double xb = (double)tested_ball.cordinator_position[0];
	double xc = (double)ball2.start_cordinator_position[0];
	double xd = (double)ball2.cordinator_position[0];

	double ya = (double)tested_ball.start_cordinator_position[1];
	double yb = (double)tested_ball.cordinator_position[1];
	double yc = (double)ball2.start_cordinator_position[1];
	double yd = (double)ball2.cordinator_position[1];

	double za = (double)tested_ball.start_cordinator_position[2];
	double zb = (double)tested_ball.cordinator_position[2];
	double zc = (double)ball2.start_cordinator_position[2];
	double zd = (double)ball2.cordinator_position[2];

	double k = ((double)ball2.t - (double)tested_ball.t) * time_scale;

	double a = pow(xd + xa - xc - xb, 2) + pow(yd + ya - yc - yb, 2) + pow(zd + za - zc - zd, 2);
	
	double half_b = (xd + xa - xc - xb) * (xc - xa + k * (xd - xc)) +
					(yd + ya - yc - yb) * (yc - ya + k * (yd - yc)) +
					(zd + za - zc - zb) * (zc - za + k * (zd - zc));
	
	double c = pow(xc - xa + k * (xd - xc), 2) + pow(yc - ya + k * (yd - yc), 2) + 
		pow(zc - za + k * (zd - zc), 2) - pow((double)tested_ball.r + ball2.r, 2);
	
	dba[0] = pow(half_b, 2) - (double)(a * c); //discriminanta (for half_b)
	dba[1] = half_b; //b / 2
	dba[2] = a; //a
}	

void get_ball_collision_t(Ball tested_ball, double* dba, double* new_t_solution)
{

	double t1 = ((-dba[1] + sqrt(dba[0])) / dba[2]) / 1;
	double t2 = ((-dba[1] - sqrt(dba[0])) / dba[2]) / 1;

	new_t_solution[0] = t1;
	new_t_solution[1] = t2;
}

double set_fixed_position_in_collision(Ball ball)
{
	Node<Ball> *follower = ball_list->next;
	Ball t_ball;
	double dba_solution[3] = {0,0,0};
	double new_t_list[2] = {0,0};
	double new_t = NULL;
	double min_new_t = NULL;
	int counter = 0;

	while (follower != nullptr && counter < bs_counter)
	{
		if (follower->value.getIdNum() != ball.getIdNum() && !follower->value.is_exploding)
		{
			follower->value.t++;
			set_next_ball_position(follower);
			t_ball = follower->value;

			follower->value.t--;
			set_next_ball_position(follower);
			
			get_discriminanta_b_a_solution(ball, t_ball, dba_solution);
			
			if (dba_solution[0] >= 0)
			{
				if (round(dba_solution[2]) == 0)
				{
					if ((round(dba_solution[1] + dba_solution[0]) == 0 || round(dba_solution[1] - dba_solution[0]) == 0) && // infinity solutions
						(min_new_t == NULL || min_new_t >= new_t))
						new_t = ball.t;
					//else no solution
				}
				else // there are 2 solutions
				{
					get_ball_collision_t(ball, dba_solution, new_t_list);
					if (fabs(ball.t - new_t_list[0]) <= fabs(ball.t - new_t_list[1]))
						new_t = new_t_list[0];
					else
						new_t = new_t_list[1];
				}

				if (min_new_t == NULL || min_new_t > new_t)
					min_new_t = new_t;
			}
		}

		follower = follower->next;
		counter++;
	}

	
	return min_new_t;
}

bool check_ball_collision(Ball ball)
{
	Node<Ball>* follower = ball_list->next;
	Ball t_ball;
	int this_summon_counter = 0;
	double distance;
	
	while (follower != nullptr && this_summon_counter < bs_counter)
	{
		if (follower->value.getIdNum() != ball.getIdNum() && !follower->value.is_exploding)
		{
			follower->value.t++;
			set_next_ball_position(follower);
			t_ball = follower->value;

			follower->value.t--;
			set_next_ball_position(follower);

			distance = sqrtf(powf((double)t_ball.cordinator_position[0] - (double)ball.cordinator_position[0], 2) +
				pow((double)t_ball.cordinator_position[1] - (double)ball.cordinator_position[1], 2) +
				pow((double)t_ball.cordinator_position[2] - (double)ball.cordinator_position[2], 2));

			if (distance <= (double)t_ball.r + (double)ball.r)
				return true;
		}

		follower = follower->next;
		this_summon_counter++;
	}
	
	return false;
}

int check_wall_collision(Ball t_ball)
{
	if (t_ball.cordinator_position[0] + t_ball.r >= room_length / 2 - wires_bulge_z) // right wall
		return 1;
	else if (t_ball.cordinator_position[0] - t_ball.r <= -room_length / 2 + wires_bulge_z) // left wall
		return 2;
	else if (t_ball.cordinator_position[1] + t_ball.r >= room_height - wires_bulge_z) // top wall
		return 3;
	else if (t_ball.cordinator_position[1] - t_ball.r <= 0 + wires_bulge_z) // bottom wall
		return 4;
	else if (t_ball.cordinator_position[2] + t_ball.r >= room_length / 2 - wires_bulge_z) // forward (in world's persective view) wall
		return 5;
	else if (t_ball.cordinator_position[2] - t_ball.r <= -room_length / 2 + wires_bulge_z) // backward (in world's persective view) wall
		return 6;
	else
		return 0;
}

int check_collision(Node<Ball>* ball)
{
	ball->value.t++;
	set_next_ball_position(ball);
	Ball t_ball = ball->value;
	
	ball->value.t--;
	set_next_ball_position(ball);

	//is there ball collision
	if (check_ball_collision(t_ball))
		return -1;

	//else if there is a wall collision
	int wall = check_wall_collision(t_ball);

	if (wall > 0)
		return wall;
	//else no collision
	return 0;
}

void move_balls()
{
	int wall = 0, counter = 0;
	Node<Ball>* main_follower = ball_list->next, * later_follower = nullptr;
	Node<Ball> *t_ball = nullptr;

	while (main_follower != nullptr && counter < bs_counter)
	{
		if(!main_follower->value.is_exploding)
		{
			wall = check_collision(main_follower);
			if (wall == 0)
				main_follower->value.new_t = main_follower->value.t + 1;
			else
			{
				t_ball = new Node<Ball>{ main_follower->value, nullptr };
				t_ball->value.t++;
				set_next_ball_position(t_ball);

				if (wall == -1)
				{
					main_follower->value.new_t = set_fixed_position_in_collision(t_ball->value);


					set_new_ball_angle(main_follower, wall);

					t_ball = new Node<Ball>{ main_follower->value, nullptr };
					t_ball->value.refresh_t();
					set_next_ball_position(t_ball);
				}

				wall = check_wall_collision(t_ball->value);

				if (wall > 0)
				{
					main_follower->value.new_t = get_coll_t(t_ball, wall);


					set_new_ball_angle(main_follower, wall);
				}

				delete t_ball;
			}
			counter++;
		}
		main_follower = main_follower->next;
	}

	main_follower = ball_list->next;
	while (main_follower != nullptr)
	{
		if (!main_follower->value.is_exploding)
		{
			main_follower->value.refresh_t();
			main_follower->value.secure_angles();
			set_next_ball_position(main_follower);
			main_follower->value.reset_start_pos_of_ball();
		}
		main_follower = main_follower->next;
	}

}

void move_explosions()
{
	float scale_speed = (explosions_max_r - explosions_min_r) / explosions_total_time;
	Node<Ball>* main_follower = ball_list->next;
	while (main_follower != nullptr)
	{
		if (main_follower->value.is_exploding)
		{
			if (main_follower->value.r > explosions_max_r && is_list_not_running)
			{
				is_list_not_running = false;
				main_follower = delete_explosion(main_follower);
				bs_counter--;
				is_list_not_running = true;
			}
			else
			{
				main_follower->value.t++;
				main_follower->value.r = explosions_min_r + scale_speed * main_follower->value.t * time_scale;
			}
		}
		main_follower = main_follower->next;
	}
}

void run_glove_impact_test(Cordinates glove_cords, float glove_r)
{
	int counter = 0;
	Node<Ball>* main_follower = ball_list->next;
	while (main_follower != nullptr && counter < bs_counter)
	{
		if (is_ball_hit(glove_cords, glove_r, main_follower->value) && !main_follower->value.is_exploding)
			explosion(&main_follower->value);
		
		counter++;
		main_follower = main_follower->next;
	}
}

bool is_ball_hit(Cordinates glove_cords, float glove_r, Ball ball)
{
	double distance = sqrtf(powf((double)glove_cords.x - (double)ball.cordinator_position[0], 2) +
		pow((double)glove_cords.y - (double)ball.cordinator_position[1], 2) +
		pow((double)glove_cords.z - (double)ball.cordinator_position[2], 2));

	if (distance <= (double)glove_r + (double)ball.r)
		return true;
	return false;
}

void explosion(Ball *hit_ball)
{
	//printf("EXPLOSION!\n");
	(*hit_ball).is_exploding = true;
	(*hit_ball).t = 0;
	(*hit_ball).r = explosions_min_r;
}

Node<Ball> *delete_explosion(Node<Ball>* hit_ball)
{
	Node<Ball>* prev_main_follower = ball_list, * main_follower = prev_main_follower->next;
	
	if (prev_main_follower->value.getIdNum() == hit_ball->value.getIdNum())
	{
		printf("ERROR! at delete_explosion, first member was about to get deleted");
		exit(0);
	}
	else
	{
		while (main_follower != nullptr && main_follower->value.getIdNum() != hit_ball->value.getIdNum())
		{
			main_follower = main_follower->next;
			prev_main_follower = prev_main_follower->next;
		}
		prev_main_follower->next = main_follower->next;
		delete(main_follower);
		return prev_main_follower;
	}
}

void run_player_impact_test()
{
	int counter = 0;
	Node<Ball> *main_follower = ball_list->next;
	while (main_follower != nullptr && counter < bs_counter)
	{
		if (!main_follower->value.is_exploding && is_player_hit_by_ball(main_follower->value))
			end_game(false);
		counter++;
		main_follower = main_follower->next;
	}
}

bool is_player_hit_by_ball(Ball ball)
{
	Cordinates ball_cords = Cordinates{ ball.cordinator_position[0], ball.cordinator_position[1], 
		ball.cordinator_position[2] };

	player_top_cords = cam_cords;
	player_middle_cords = cam_cords.sum(Cordinates{ 0, player_tops_r - player_height_above_0 / 2 , 0 });
	player_bottom_cords = cam_cords.sum(Cordinates{ 0, -player_height_above_0 + 2 * player_tops_r, 0 });

	double distance;

	//top check
	distance = ball_cords.getDistanceWith(player_top_cords);
	if (distance < ball.r + player_tops_r)
	{
		//printf("top detected\n");
		return true;
	}
	
	//bottom check
	distance = ball_cords.getDistanceWith(player_bottom_cords);
	if (distance < ball.r + player_tops_r)
	{
		//printf("bottom detected\n");
		return true;
	}

	distance = ball_cords.getDistanceWith(Cordinates{ player_middle_cords.x, ball_cords.y, player_middle_cords.z});
	if (distance < ball.r + player_tops_r)
	{
		if (ball_cords.y < player_top_cords.y && ball_cords.y > player_bottom_cords.y)
		{
			//printf("middle detected\n");
			return true;
		}
	}
	return false;
}

void end_game(bool is_win)
{
	is_player_win = is_win;
	is_game_end = true;
	/*if (is_win)
		printf("\nyou win!\n");
	else
		printf("\ngame over\n");*/
	loosing_cam_cords = cam_cords;
	shooting_cam_alpha = cam_alpha;
	shooting_cam_beta = cam_beta;
	glutTimerFunc(delay_game_over_time, delay_func, d3);
}

void initial_display_list(void) {
	for (int i = 0; i < sizeof(index) / sizeof(GLuint); i++)
		index[i] = glGenLists(i + 1);

	glNewList(index[0], GL_COMPILE);
	create_custom_room();
	glEndList();

	glNewList(index[1], GL_COMPILE);
	draw_gun_body(gun_body_width, gun_body_length, gun_body_color);
	glEndList();

	glNewList(index[2], GL_COMPILE);
	draw_gun_spring(gun_body_width, gs_total_start_len, gun_spring_color, gs_circles_num, gun_spring_layer);
	glEndList();

	glNewList(index[3], GL_COMPILE);
	draw_glove(glove_r, glove_color);
	glEndList();

	glNewList(index[4], GL_COMPILE);
	custom3D_circle(explosions_color, explosions_min_r);
	glEndList();

	glNewList(index[5], GL_COMPILE);
	draw_player(player_tops_r, player_height_above_0, player_color);
	glEndList();

	glNewList(index[6], GL_COMPILE);
	mouse_mark(mouse_mark_cr, mouse_mark_cd);
	glEndList();
}

void initial_to_persective(void)
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(cam_angle_view, cam_propotion, cam_min_d, cam_max_d);
	glMatrixMode(GL_MODELVIEW);
}

void initial_to_ortho(void)
{
	glClearColor(b_home_color[0], b_home_color[1], b_home_color[2], 1);
	glViewport(0, 0, curr_XWinSize, curr_YWinSize);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(curr_left, curr_right, curr_down, curr_up, curr_near, curr_far);
	glMatrixMode(GL_MODELVIEW);
}

void reshape_persective(int w, int h)
{
	can_start_move = false;
	glutTimerFunc(delay_play_time, delay_func, d1);

	if (h == 0) h = 1;
	cam_propotion = (float)w / h;

	curr_XWinSize = w;
	curr_YWinSize = h;

	if(on_fullscreen) 
		glutFullScreen();
	else 
		glutReshapeWindow(curr_XWinSize, curr_YWinSize);

	initial_to_persective();
}

void reshape_ortho(int w, int h)
{
	curr_XWinSize = w;
	curr_YWinSize = h;

	if (on_fullscreen)
		glutFullScreen();
	else
		glutReshapeWindow(curr_XWinSize, curr_YWinSize);
	
	glEnable(GL_DEPTH_TEST);
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	//initial_to_ortho();

	if (w <= h)
	{
		curr_left = XLeft;
		curr_right = XRight;
		curr_down = YDown * (GLfloat)h / (GLfloat)w;
		curr_up = YUp * (GLfloat)h / (GLfloat)w;
	}

	else
	{
		curr_left = XLeft * (GLfloat)w / (GLfloat)h;
		curr_right = XRight * (GLfloat)w / (GLfloat)h;
		curr_down = YDown;
		curr_up = YUp;
	}
	curr_near = ZNear;
	curr_far = ZFar;

	glOrtho(curr_left, curr_right, curr_down, curr_up, curr_near, curr_far);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	cam_propotion = (float)w / h;
}

void SpecialKeys(int key, int x, int y)
{
	if (key == GLUT_KEY_F11 && !keypressed[key])
	{
		if (!on_fullscreen && can_start_move)
		{
			//cam_propotion = 1.778;
			on_fullscreen = true;
			if (is_game_start)
				reshape_persective(glutGet(GLUT_SCREEN_WIDTH), glutGet(GLUT_SCREEN_HEIGHT));
			else
				reshape_ortho(glutGet(GLUT_SCREEN_WIDTH), glutGet(GLUT_SCREEN_HEIGHT));
		}
		else if (can_start_move)
		{
			on_fullscreen = false;
			if (is_game_start)
				reshape_persective(XWINSIZE, YWINSIZE);
			else
				reshape_ortho(XWINSIZE, YWINSIZE);
		}
	}

	keypressed[key] = true;
}


void pressed_keyboard(unsigned char key, int x, int y)
{
	keypressed[tolower(key)] = true;
}

void released_keyboard(unsigned char key, int x, int y)
{
	keypressed[tolower(key)] = false;
}

void released_SpecialKeys(int key, int x, int y)
{
	keypressed[key] = false;
}

void idle() {

	if (is_contiue_playing)
	{
		if (keypressed['q'] || keypressed['Q'])
			exit(0);

		if (is_game_start)
		{
			if (ball_list->next == nullptr && is_list_not_running && !is_game_end)
				end_game(true);

			if (keypressed['a'])
			{
				cam_z += character_speed * sin(cam_alpha * PI / 180);
				cam_x += character_speed * cos(cam_alpha * PI / 180);
			}
			if (keypressed['d'])
			{
				cam_z -= character_speed * sin(cam_alpha * PI / 180);
				cam_x -= character_speed * cos(cam_alpha * PI / 180);
			}
			if (keypressed['w'])
			{
				cam_z += character_speed * cos(cam_alpha * PI / 180);
				cam_x -= character_speed * sin(cam_alpha * PI / 180);
			}
			if (keypressed['s'])
			{
				cam_z -= character_speed * cos(cam_alpha * PI / 180);
				cam_x += character_speed * sin(cam_alpha * PI / 180);
			}

			if (is_jump)
			{
				i++;
				next_current_jump_distance = player_height_above_0 + start_jump_speed * i * time_scale + g * powf(i * time_scale, 2) / 2;

				if (cam_y + player_height_above_0 + next_current_jump_distance < cam_y + player_height_above_0)
				{
					current_jump_distance = 0;
					is_jump = false;
				}
				else
					current_jump_distance = player_height_above_0 + start_jump_speed * i * time_scale + g * powf(i * time_scale, 2) / 2;
			}

			run_borders_test();

			glutWarpPointer(curr_XWinSize / 2, curr_YWinSize / 2);
			if (is_game_end)
				glutSetCursor(GLUT_CURSOR_DESTROY);
			else
				glutSetCursor(GLUT_CURSOR_CROSSHAIR);
		}
	}

	if (is_game_start && is_contiue_playing && !is_game_end)
	{
		move_balls();
		move_explosions();

		if (mouse[0])
			is_gun_shooting = true;
		if (keypressed[' '] && !is_jump)
		{
			current_jump_distance = 0;
			start_jump_speed = sqrtf(-2 * g * player_jump_distance);
			i = 0;
			is_jump = true;
		}

		if (is_gun_shooting)
		{
			if (spring_extention == 0 && !is_max_extention_reached)
			{
				shooting_cam_alpha = cam_alpha;
				shooting_cam_beta = cam_beta;
				shooting_cam_cords = { cam_x, cam_y, cam_z };
				//printf("\nshooting\n\n");
			}

			Cordinates spring_gun_cords = get_position_prob_to_player(gun_position_x_pro_to_player - gun_body_length * sin(gun_angle_x * PI / 180),
			gun_position_y_pro_to_player,
			gun_position_z_pro_to_player + gun_body_length * cos(gun_angle_x * PI / 180),0, 0, Cordinates{0, 0, 0});

			Cordinates hit_point = get_position_prob_to_player(0, 0,gun_position_z_pro_to_player 
				+ gun_body_length * cos(gun_angle_x * PI / 180) + max_glove_length + glove_r, 0, 0, Cordinates{0, 0, 0});
			
			Cordinates vector_r = hit_point.sub_for_vector_with(spring_gun_cords);
			Cordinates vector_y = get_position_prob_to_player(0, 1, 0, 0, 0, Cordinates{0, 0, 0});

			shoot_angle_beta = 90 - acos((vector_y.scalar_product_vector(vector_r))/ (vector_y.len() * vector_r.len())) * 180 / PI;

			float u = vector_r.z;
			float v = vector_r.x;
			shoot_angle_alpha = atan(u / v) * 180 / PI;
			shoot_angle_alpha = 90 - shoot_angle_alpha;
			
			if (!is_max_extention_reached)
			{
				if (spring_extention * gs_total_start_len < max_glove_length)
				{
					if (spring_extention * gs_total_start_len + shooting_speed > max_glove_length)
						spring_extention = max_glove_length / gs_total_start_len;
					else
						spring_extention += shooting_speed/ gs_total_start_len;
				}
				else
					is_max_extention_reached = true;
			}
			else
			{
				if (spring_extention > 0)
				{
					if (spring_extention - shooting_speed / gs_total_start_len < 0)
						spring_extention = 0;
					else
						spring_extention -= shooting_speed / gs_total_start_len;
				}
				else
				{
					is_max_extention_reached = false;
					is_gun_shooting = false;
				}
			}

			Cordinates this_glove_cords = glove_cords;

			run_glove_impact_test(this_glove_cords, glove_r);
		}

		run_player_impact_test();
	}
	if (is_game_start && is_window_focused)
	{
		if (!is_contiue_playing && mouse[0]) //mouse[0] = left click
			contiue_game();
	}

	glutPostRedisplay();
}

void run_borders_test()
{
	if (cam_x > room_length / 2 - 1)
		cam_x = room_length / 2 - 1;
	if (cam_x < -room_length / 2 + 1)
		cam_x = -room_length / 2 + 1;
	if (cam_z > room_length / 2 - 1)
		cam_z = room_length / 2 - 1;
	if (cam_z < -room_length / 2 + 1)
		cam_z = -room_length / 2 + 1;
	
	if (cam_y + player_height_above_0 + current_jump_distance > room_height)
		current_jump_distance = room_height - 1 - player_height_above_0;
}

void passiveMouse(int x, int y) {

	if (is_game_start)
	{
		float mouse_change_posx = (x - curr_XWinSize / 2) / (curr_XWinSize / 2);
		float mouse_change_posy = -(y - curr_YWinSize / 2) / (curr_YWinSize / 2);


		if (can_start_move && is_contiue_playing)
		{
			if (x > curr_XWinSize / 2 + angle_distortion) //mouse moved right
				cam_alpha += cam_max_rotate_speed * mouse_change_posx;
			else if (x < curr_XWinSize / 2 - angle_distortion) //mouse moved left
				cam_alpha += cam_max_rotate_speed * mouse_change_posx;

			if (y > curr_YWinSize / 2 + angle_distortion) //mouse moved down
			{
				if (cam_beta + cam_max_rotate_speed * mouse_change_posy > -90)
					cam_beta += cam_max_rotate_speed * mouse_change_posy;
				else
					cam_beta = -89.9;
			}
			if (y < curr_YWinSize / 2 - angle_distortion) //mouse moved up
			{
				if (cam_beta + cam_max_rotate_speed * mouse_change_posy < 90)
					cam_beta += cam_max_rotate_speed * mouse_change_posy;
				else
					cam_beta = 89.9;
			}
		}
	}
	else
	{
		float clickX = curr_XWinSize / (fabs(curr_left) + fabs(curr_right));
		float clickY = curr_YWinSize / (fabs(curr_up) + fabs(curr_down));

		dx = curr_left + x / clickX;
		dy = curr_down + (curr_YWinSize - y) / clickY;
	}

	glutPostRedisplay();
}

void onMouseClick(int button, int state, int x, int y) {
	
	if (is_game_start)
	{
		if (state == GLUT_DOWN)
		{
			mouse[button] = true;
		}
		else //released
			mouse[button] = false;
	}
	else
	{
		if (((show_home_screen && play_button.is_hovered(dx, dy)) ||
			(show_results_screen && try_again_button.is_hovered(dx, dy) && !is_player_win) || 
			(show_results_screen && play_again_button.is_hovered(dx, dy) && is_player_win)) && button == 0 && state == GLUT_UP) //left click
			start_game();

		else if((show_results_screen && is_player_win && back_title_button.is_hovered(dx , dy) ||
			back_title_button2.is_hovered(dx, dy) && show_guide_screen ||
			back_title_button2.is_hovered(dx, dy) && show_credits_screen ||
			back_title_button2.is_hovered(dx, dy) && show_results_screen && !is_player_win) && button == 0 && state == GLUT_UP)
		{
			close_all_screens();
			show_home_screen = true;
		}

		else if ( (show_home_screen && guide_title_button.is_hovered(dx, dy) || (show_results_screen && !is_player_win && 
			guide_title_button.is_hovered(dx, dy))) && button == 0 && state == GLUT_UP)
		{
			close_all_screens();
			show_guide_screen = true;
		}
		else if ((show_home_screen && credit_button.is_hovered(dx, dy)) && button == 0 && state == GLUT_UP)
		{
			close_all_screens();
			show_credits_screen = true;
		}

	}
}

void start_game()
{
	close_all_screens();
	is_game_end = false;
	cam_alpha = start_cam_alpha;
	cam_beta = start_cam_beta;
	cam_x = start_cx; cam_y = start_cy; cam_z = start_cz;
	bs_counter = 0;
	dx = 0; dy = 0;
	current_jump_distance = 0;
	spring_extention = 0;
	create_balls();
	glutDisplayFunc(display);
	glutReshapeFunc(NULL);
	initial_to_persective();
	is_game_start = true;
}

void close_game_and_show_results()
{
	is_game_start = false;
	glutSetCursor(GLUT_CURSOR_INHERIT);
	initial_to_ortho();
	glutDisplayFunc(display2D);
	glutReshapeFunc(reshape_ortho);
	show_results_screen = true;
}

void pause_game()
{
	is_contiue_playing = false;
	is_window_focused = false;
	
	glutSetCursor(GLUT_CURSOR_INHERIT);
	initial_to_ortho();
	glutDisplayFunc(display2D);
	glutReshapeFunc(reshape_ortho);
	show_pause_screen = true;
}

void contiue_game()
{
	show_pause_screen = false;

	glutDisplayFunc(display);
	glutReshapeFunc(NULL);
	initial_to_persective();

	mouse[0] = false;
	glutWarpPointer(curr_XWinSize / 2, curr_YWinSize / 2);
	glutSetCursor(GLUT_CURSOR_CROSSHAIR);
	is_contiue_playing = true;
}

void close_all_screens()
{
	show_credits_screen = false;
	show_home_screen = false;
	show_results_screen = false;
	show_guide_screen = false;
	is_game_start = false;
}

void testmouse(int state)
{
	if (is_game_start)
	{
		if (state == GLUT_ENTERED)
			is_window_focused = true;
		else
			pause_game();
	}
}

Cordinates get_position_prob_to_player(float x, float y, float z, double curr_cam_alpha, double curr_cam_beta, 
	Cordinates curr_cam_cords)
{
	Cordinates new_position = {
	curr_cam_cords.x + x * -cos(curr_cam_alpha * PI / 180) 
		+ y * sin(curr_cam_beta * PI / 180) * sin(curr_cam_alpha * PI / 180)
		+ z * -sin(curr_cam_alpha * PI / 180) * cos(curr_cam_beta * PI / 180),
	curr_cam_cords.y + y * cos(curr_cam_beta * PI / 180)
		+ z * sin(curr_cam_beta * PI / 180),
	curr_cam_cords.z + x * -sin(curr_cam_alpha * PI / 180)
		+ y * -sin(curr_cam_beta * PI / 180) * cos(curr_cam_alpha * PI / 180)
		+ z * cos(curr_cam_alpha * PI / 180) * cos(curr_cam_beta * PI / 180)
	};


	/*x:
	Cordinates new_position = {
		cam_cords.x + x * -cos(cam_alpha * PI / 180),
		cam_cords.y,
		cam_cords.z + x * -sin(cam_alpha * PI / 180)
	};*/


	//y:
	/*Cordinates new_position = {
		cam_cords.x + y * sin(cam_beta * PI / 180) * sin(cam_alpha * PI / 180),
		cam_cords.y + y * cos(cam_beta * PI / 180),
		cam_cords.z + y * -sin(cam_beta * PI / 180) * cos(cam_alpha * PI / 180)
	};*/

	//z:
	/*Cordinates new_position = {
		cam_cords.x + z * -sin(cam_alpha * PI / 180) * cos(cam_beta * PI / 180),
		cam_cords.y + z * sin(cam_beta * PI / 180),
		cam_cords.z + z * cos(cam_alpha * PI / 180) * cos(cam_beta * PI / 180)
	};*/

	return new_position;
}

int main(int argc, char** argv) {
	srand((unsigned)time(&t));

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_DEPTH | GLUT_RGBA);
	glutInitWindowPosition(0, 0);
	glutInitWindowSize(curr_XWinSize, curr_YWinSize);
	glutCreateWindow("First");
	glutPositionWindow(0, 0);
	
	initial_display_list();
	initial_to_ortho();
	glutDisplayFunc(display2D);

	glutIdleFunc(idle);
	glutKeyboardFunc(pressed_keyboard);
	glutKeyboardUpFunc(released_keyboard);
	glutSpecialFunc(SpecialKeys);
	glutSpecialUpFunc(released_SpecialKeys);
	glutPassiveMotionFunc(passiveMouse);
	glutMotionFunc(passiveMouse);
	glutMouseFunc(onMouseClick);
	glutTimerFunc(delay_play_time, delay_func, d1);
	glutEntryFunc(testmouse);

	glViewport(0, 0, curr_XWinSize, curr_YWinSize);
	glutReshapeFunc(reshape_ortho);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glutMainLoop();
}