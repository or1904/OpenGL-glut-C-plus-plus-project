#ifndef BALL
#define BALL

#include "Node.h"

class Ball
{

private:
	int id_num;
	float m; //mass in g
	float nobs_to_summon; // num of balls to summon after being hit
	float color[3];

public:
	float r; //ball's radius
	float start_cordinator_position[3]; // save the start coords of center of the ball
	float cordinator_position[3]; // save the coords of center of the ball
	double alpha_movement; //angle of movement in horizontal direction
	double beta_movement; //angle of movement in vertical direction
	
	double new_alpha_movement;
	double new_beta_movement;

	double t; // time value, in sec
	double new_t; //new time value, in sec

	bool is_exploding;

	Ball();
	Ball(int id_num, float r, float start_cordinator_position[3], float cordinator_position[3], float m, float alpha, float beta, float num_of_balls_to_summon, float color[3], bool is_drawn);
	int getIdNum();
	float getM();
	float getColor(int i);

	void reset_start_pos_of_ball();
	void refresh_t();
	void secure_angles();
};

#endif