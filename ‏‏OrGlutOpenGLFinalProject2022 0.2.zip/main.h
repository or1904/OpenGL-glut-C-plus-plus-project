// instructions:

/*
momvement: a,w,d,s
looking: mouse movement
jump: space_bar
full_screen: f11
exit: q
*/


#ifndef MAIN
#define MAIN

#include "Ball.h"
#include "Shapes.h"
#include "Node.h"
#include "Cordinates.h"
#include "Text.h"
#include "Button.h"

#include <stdlib.h>
#include <stdio.h>
#include <glut.h>
#include <math.h>

#pragma once
extern double cam_alpha;
extern double cam_beta;
extern Cordinates cam_cords;

void initial_to_persective(void);
void initial_to_ortho(void);
void delay_func(int value);
Node<Ball>* create_a_ball();
void create_balls();
void set_next_ball_position(Node<Ball>* ball);
void draw_balls_and_explosions();
void draw_a_ball_and_explosion(Node<Ball>* b, int counter, float d_common);
void reshape_persective(int w, int h); // h != 0
void move_balls();
void move_explosions();
int check_collision(Node<Ball>* ball); // 1 - right, 2 - left, 3 - up, 4 - down, 5 - forward (in world's persective view), 6 - backward (in world's persective view), -1 - ball collision
double get_coll_t(Node<Ball>* ball, int wall); 
void set_new_ball_angle(Node<Ball>* ball, int wall);
bool check_ball_collision(Ball ball); //return if ball collision happens
int check_wall_collision(Ball t_ball);
double set_fixed_position_in_collision(Ball ball); // set right t for that ball in collision
void get_discriminanta_b_a_solution(Ball tested_ball, Ball ball2, double *dba); //return discriminanta, b/2 and denominator (a) for t solutions in ball collision as array
void get_ball_collision_t(Ball tested_ball, double *dba, double *new_t_solution); //return t solutions for a ball collision with this other ball.
Cordinates get_position_prob_to_player(float x, float y, float z, 
	double curr_cam_alpah = cam_alpha, double curr_cam_beta = cam_beta, 
	Cordinates curr_cam_cords = cam_cords); //axes according to persective axes
void run_glove_impact_test(Cordinates glove_cords, float glove_r);
bool is_ball_hit(Cordinates glove_cords, float glove_r, Ball ball);
void explosion(Ball *hit_ball); //also change ball_list
Node<Ball> *delete_explosion(Node<Ball> *ball); //return the next member after the chosen member
void run_player_impact_test();
bool is_player_hit_by_ball(Ball ball);
void run_borders_test();
void end_game(bool is_win);
void start_game();
void close_game_and_show_results();
void close_all_screens();
void pause_game();
void contiue_game();

#endif