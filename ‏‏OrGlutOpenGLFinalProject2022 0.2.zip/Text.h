#pragma once

#ifndef TEXT
#define TEXT

#include <glut.h>
#include "Cordinates.h"

class Text
{
private:
	const unsigned char* title;
public:
	void* font;
	Cordinates cords;
	float color[3];
	float width;
	float size;
	bool is_center;
	bool is_smooth;


	Text(const unsigned char* title, void* font, Cordinates cords, float color[3], float width, float size, bool is_center, bool is_smooth);
	
	const unsigned char *getTitle();

	float get_printed_string_length();

};

#endif
