#pragma once

#ifndef SMH
#define SMA

#pragma once
#include "Cordinates.h"
#include "Text.h"
#include "Button.h"
//#include <string>

extern float dx;
extern float dy;

void filled_cube();
void filled_square();
void custom_wall(float wall_length, float wall_height, float total_length, float total_height);
void custom_cube(float cube_length, float cube_height, float wires_width, float color[]);
void mouse_mark(float r, float d_from_cam);
void filled_circle(float r);
void circle(float r, float alpha);
void build_filled_circle(float r, float alpha);
void custom3D_circle(float explosion_color[3], float explosions_start_r);
void create_custom_room();
void draw_gun_body(float gun_body_width, float gun_body_length, float gun_body_color[3]);
void draw_gun_spring(float gun_spring_width, float gs_total_length, float gun_spring_color[3], int gs_circles_num, float gun_spring_layer);
void draw_spirala(int circles_num, float start_layer);
void draw_glove(float glove_r, float glove_color[3]);
void draw_player(float tops_r, float player_height, float player_color[4]);
void draw_text(Text title);
void draw_button(Button b, float x = dx, float y = dy);

#endif