#include "Text.h"

Text::Text(const unsigned char* title, void* font, Cordinates cords, float color[3], float width,
	float size, bool is_center, bool is_smooth) :
	title(title),
	font(font),
	cords(cords),
	color{ color[0], color[1], color[2] },
	width(width),
	size(size),
	is_center(is_center),
	is_smooth(is_smooth)
	{}

const unsigned char* Text::getTitle()
{
	return this->title;
}

float Text::get_printed_string_length()
{
	return glutStrokeLength(this->font, this->title);
}