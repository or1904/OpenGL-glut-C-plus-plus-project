#include "Button.h"

Button::Button(Text text, float w, float h, float field_color[3]) :
	text(text),
	field_w(w),
	field_h(h),
	field_color{ field_color[0],field_color[1],field_color[2] }
{
	if (this->text.is_center)
		field_cords = this->text.cords;
	else
	{
		field_cords = Cordinates{
			this->text.cords.x + this->text.get_printed_string_length() / 2,
			this->text.cords.y, this->text.cords.z };
	}

}

bool Button::is_hovered(float x, float y)
{
	if (x < this->field_cords.x + this->field_w / 2 && x > this->field_cords.x - this->field_w / 2 &&
		y < this->field_cords.y + this->field_h / 2 && y > this->field_cords.y - this->field_h / 2)
		return true;
	//else
	return false;
}

