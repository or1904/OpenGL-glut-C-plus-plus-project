
#include <stdlib.h>
#include <stdio.h>
#include <glut.h>
#include <math.h>

#include "Main.h"
#include "Shapes.h"

extern const double PI;

extern float wires_bulge_z;
extern float wires_width, wires_color[3];
extern float mouse_mark_cd;
extern float cam_min_d;
extern float custom_floor_height;
extern float custom_floor_length;
extern float custom_wall_height;
extern float custom_wall_length;
extern float room_length;
extern float room_height;
extern float gun_body_width;
extern float gun_body_length;
extern double gun_position_x_pro_to_player;
extern float gun_body_color[3];

void filled_cube()
{
	glBegin(GL_POLYGON); // down base
	glVertex3f(-1, -1, -1);
	glVertex3f(1, -1, -1);
	glVertex3f(1, -1, 1);
	glVertex3f(-1, -1, 1);
	glVertex3f(-1, -1, -1);
	glEnd();

	glBegin(GL_POLYGON); //upper base
	glVertex3f(-1, 1, -1);
	glVertex3f(1, 1, -1);
	glVertex3f(1, 1, 1);
	glVertex3f(-1, 1, 1);
	glVertex3f(-1, 1, -1);
	glEnd();

	glBegin(GL_POLYGON); // chest shell 1
	glVertex3f(-1, -1, -1);
	glVertex3f(-1, 1, -1);
	glVertex3f(-1, 1, 1);
	glVertex3f(-1, -1, 1);
	glEnd();

	glBegin(GL_POLYGON); // chest shell 2
	glVertex3f(1, -1, 1);
	glVertex3f(1, 1, 1);
	glVertex3f(-1, 1, 1);
	glVertex3f(-1, -1, 1);
	glEnd();

	glBegin(GL_POLYGON); // chest shell 3
	glVertex3f(1, -1, -1);
	glVertex3f(1, 1, -1);
	glVertex3f(1, 1, 1);
	glVertex3f(1, -1, 1);
	glEnd();

	glBegin(GL_POLYGON); // chest shell 4
	glVertex3f(1, -1, -1);
	glVertex3f(1, 1, -1);
	glVertex3f(-1, 1, -1);
	glVertex3f(-1, -1, -1);
	glEnd();
}

void filled_square()
{
	glBegin(GL_POLYGON);
	glVertex3f(-1, -1, 0);
	glVertex3f(1, -1, 0);
	glVertex3f(1, 1, 0);
	glVertex3f(-1, 1, 0);
	glEnd();
}

void custom_wall(float wall_length, float wall_height, float total_length, float total_height)
{
	float num_of_custom_walls_x = total_length / wall_length;
	float num_of_custom_walls_y = total_height / wall_height;
	float deviation_x = num_of_custom_walls_x - (int)(num_of_custom_walls_x);
	float deviation_y = num_of_custom_walls_y - (int)(num_of_custom_walls_y);

	for (int posx = -deviation_x / 2; posx < total_length; posx += wall_length)
	{
		for (int posy = -deviation_y / 2; posy < total_height; posy += wall_height)
		{
			glPushMatrix();
			glTranslatef(posx, posy, 0);
			glTranslatef(wall_length / 2, wall_height / 2, 0); //fix center of shape to the bottom-left
			custom_cube(wall_length, wall_height, wires_width, wires_color);
			glPopMatrix();
		}
	}
}

void custom_cube(float cube_length, float cube_height, float wires_width, float color[])
{
	glPushMatrix(); //outside-wall
	glColor3f(1, 1, 1);
	glScalef(cube_length / 2, cube_height / 2, 1);
	filled_square();
	glPopMatrix();

	glPushMatrix(); //iner-wall
	glColor3f(color[0], color[1], color[2]);
	glTranslatef(0, 0, wires_bulge_z);
	glScalef((cube_length - 2 * wires_width) / 2, (cube_height - 2 * wires_width) / 2, wires_bulge_z);
	filled_cube();
	glPopMatrix();
}

void mouse_mark(float r, float d_from_cam)
{
	glPushMatrix();
	glTranslatef(0, 0, -d_from_cam);
	filled_circle(r);
	glPopMatrix();
}

void filled_circle(float r)
{
	glPushMatrix();
	glBegin(GL_LINE_LOOP);
	circle(r, 0);
	glEnd();

	glBegin(GL_LINES);
	build_filled_circle(r, 0);
	glEnd();
	glPopMatrix();
}

void circle(float r, float alpha)
{
	glVertex3f(r * cos(alpha * PI / 180), r * sin(alpha * PI / 180), 0);
	if (alpha < 360)
		circle(r, alpha + 0.1);
}

void build_filled_circle(float r, float alpha)
{
	glVertex3f(r * cos(alpha * PI / 180), r * sin(alpha * PI / 180), 0);
	glVertex3f(0, 0, 0);
	if (alpha < 360)
		build_filled_circle(r, alpha + 0.1);
}

void create_custom_room()
{
	//front wall
	glPushMatrix();
	glTranslatef(-room_length / 2, 0, -room_length / 2);
	custom_wall(custom_wall_length, custom_wall_height, room_length, room_height);
	glPopMatrix();

	//backward wall
	glPushMatrix();
	glRotatef(180, 0, 1, 0);
	glTranslatef(-room_length / 2, 0, -room_length / 2);
	custom_wall(custom_wall_length, custom_wall_height, room_length, room_height);
	glPopMatrix();

	//right wall
	glPushMatrix();
	glRotatef(270, 0, 1, 0);
	glTranslatef(-room_length / 2, 0, -room_length / 2);
	custom_wall(custom_wall_length, custom_wall_height, room_length, room_height);
	glPopMatrix();

	//left wall
	glPushMatrix();
	glRotatef(90, 0, 1, 0);
	glTranslatef(-room_length / 2, 0, -room_length / 2);
	custom_wall(custom_wall_length, custom_wall_height, room_length, room_height);
	glPopMatrix();

	//bottom floor
	glPushMatrix();
	glRotatef(270, 1, 0, 0);
	glTranslatef(-room_length / 2, -room_length / 2, 0);
	//glTranslatef(-room_length / 2, -room_length / 2, 0 + 0.4);
	custom_wall(custom_floor_length, custom_floor_height, room_length, room_length);
	glPopMatrix();

	//top floor
	glPushMatrix();
	glRotatef(90, 1, 0, 0);
	glTranslatef(-room_length / 2, -room_length / 2, -room_length / 2);
	custom_wall(custom_floor_length, custom_floor_height, room_length, room_length);
	glPopMatrix();
}

void draw_gun_body(float gun_body_width, float gun_body_length, float gun_body_color[3])
{
	glPushMatrix();
	glColor3f(gun_body_color[0], gun_body_color[1], gun_body_color[2]);
	glScalef(gun_body_width, gun_body_width, gun_body_length / 2);
	glTranslatef(0, 0, 1);
	filled_cube();
	glPopMatrix();
}

void draw_gun_spring(float gun_spring_width, float gs_total_length, float gun_spring_color[3], int gs_circles_num, float gun_spring_layer)
{
	glPushMatrix();
	glColor3f(gun_spring_color[0], gun_spring_color[1], gun_spring_color[2]);
	glScalef(gun_spring_width, gun_spring_width, gs_total_length);
	draw_spirala(gs_circles_num, gun_spring_layer); 
	glPopMatrix();
}

void draw_spirala(int circles_num, float start_layer)
{
	int n_ribs_per_one = 100;
	int i = 0;
	float x = cos(i * 2 * PI / n_ribs_per_one);
	float y = sin(i * 2 * PI / n_ribs_per_one);
	double z = 0;

	glPushMatrix();
	glBegin(GL_LINES);
	glTranslated(0, 0, start_layer);
	glVertex3f(x, y, z);
	z += 1.0 / (float(n_ribs_per_one) * float(circles_num));
	for (i = 1; i < n_ribs_per_one * circles_num; i++)
	{
		x = cos(i * 2 * PI / n_ribs_per_one);
		y = sin(i * 2 * PI / n_ribs_per_one);
		glVertex3f(x, y, z);
		glVertex3f(x, y, z);
		z +=  1.0 / (float(n_ribs_per_one) * float(circles_num));
	}
	glEnd();
	glPopMatrix();
}

void draw_glove(float glove_r, float glove_color[3])
{
	glPushMatrix();
	glColor3f(glove_color[0], glove_color[1], glove_color[2]);
	glutSolidSphere(glove_r, 100, 100);
	glPopMatrix();
}

void custom3D_circle(float explosion_color[3], float explosions_start_r)
{
	float x = 0, y = 0, z = 0;
	int n = 300;
	float outer_r = 0.1, ball_r = 1;
	glPushMatrix();
	glScalef(explosions_start_r, explosions_start_r, explosions_start_r);
	glColor3f(explosion_color[0], explosion_color[1], explosion_color[2]);
	glBegin(GL_LINES);
	for (int i = 0; i < n; i++)
	{
		y = (ball_r + outer_r) * sin(i * 2 * PI / n);
		for (int i2 = 0; i2 < n; i2++)
		{
			x = cos(i2 * 2 * PI / n) * cos(i * 2 * PI / n);
			z = sin(i2 * 2 * PI / n) * cos(i * 2 * PI / n);
			glVertex3f(x, y, z);
			x = (ball_r + outer_r) * cos(i2 * 2 * PI / n) * cos(i * 2 * PI / n);
			z = (ball_r + outer_r) * sin(i2 * 2 * PI / n) * cos(i * 2 * PI / n);
			glVertex3f(x, y, z);
		}
	}
	glEnd();
	glPopMatrix();
}

void draw_player(float tops_r, float player_height, float player_color[4])
{
	if (player_height <= 2 * tops_r)
	{
		printf("ERROR! at draw_player: height above 0 of player is too small:%f < %f", player_height, 2 * tops_r);
		exit(0);
	}
	GLUquadricObj* quadratic = gluNewQuadric(); //for drawing cylinder
	float chest_height = player_height - 2 * tops_r;

	glPushMatrix();
	glColor4f(player_color[0], player_color[1], player_color[2], player_color[4]);

	glPushMatrix();
	glTranslatef(0, 0, 0);
	glutSolidSphere(tops_r, 100, 100);
	glPopMatrix();

	glPushMatrix();
	//glColor3f(player_color[0], player_color[1], player_color[2]);
	glTranslatef(0, - chest_height / 2, 0);
	glRotatef(90, 1, 0, 0);
	glTranslatef(0, 0, -chest_height / 2);
	gluCylinder(quadratic, tops_r, tops_r, chest_height, 100, 100);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0, - chest_height, 0);
	glutSolidSphere(tops_r, 100, 100);
	glPopMatrix();

	glPopMatrix();
}

void draw_text(Text title)
{
	glPushMatrix();
	if (title.is_smooth)
		glEnable(GL_LINE_SMOOTH);
	else
		glDisable(GL_LINE_SMOOTH);

	glTranslatef(title.cords.x, title.cords.y, title.cords.z);
	glColor3f(title.color[0], title.color[1], title.color[2]);

	//float length = glutStrokeLength(title.font, title.getTitle());
	float length = title.get_printed_string_length();

	glLineWidth(title.width);
	if(title.is_center)
		glTranslatef(-length * title.size, 0, 0);
	else
		glTranslatef(-length * title.size / 2, 0, 0);
	glScalef(title.size, title.size, 0);
	glTranslatef(length / 2, 0, 0);

	int i = 0;

	while (*(title.getTitle() + i))
	{
		glutStrokeCharacter(title.font, *(title.getTitle() + i));
		i++;
	}
	glLineWidth(1);

	glPopMatrix();
}

void draw_button(Button b, float x, float y)
{
	draw_text(b.text);

	glPushMatrix();
	glColor3f(b.field_color[0], b.field_color[1], b.field_color[2]);
	glLineWidth(b.text.size);
	if(b.is_hovered(x, y))
		glBegin(GL_POLYGON);
	else
		glBegin(GL_LINE_LOOP);
	glVertex3f(b.field_cords.x - b.field_w / 2, b.field_cords.y - b.field_h / 2, b.field_cords.z - 1);
	glVertex3f(b.field_cords.x - b.field_w / 2, b.field_cords.y + b.field_h / 2, b.field_cords.z - 1);
	glVertex3f(b.field_cords.x + b.field_w / 2, b.field_cords.y + b.field_h / 2, b.field_cords.z - 1);
	glVertex3f(b.field_cords.x + b.field_w / 2, b.field_cords.y - b.field_h / 2, b.field_cords.z - 1);
	glEnd();
	glLineWidth(1);
	glPopMatrix();
}