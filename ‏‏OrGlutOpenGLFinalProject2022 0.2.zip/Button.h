#pragma once

#ifndef BUTTON
#define BUTTON

#include "Text.h"

class Button
{
public:
	Text text;
	float field_w; //width
	float field_h; //height
	Cordinates field_cords;
	float field_color[3];

	Button(Text text, float w, float h, float field_color[3]);
	bool is_hovered(float x, float y);

};

#endif